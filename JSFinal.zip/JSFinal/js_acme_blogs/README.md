# Acme Blogs

[![Remix on Glitch](https://cdn.glitch.com/2703baf2-b643-4da7-ab91-7ee2a2d00b5b%2Fremix-button.svg)](https://glitch.com/edit/#!/import/github/gitdagray/js_acme_blogs)

**Start by clicking the Remix on Glitch button above.**

_Once you are working with your own copy of the project on Glitch..._

**Follow the directions available in Blackboard** 

_DO NOT CHANGE any of the pre-existing code. Your code only goes in main.js._

Did you miss some?

It's ok. Go back and make corrections. Then check your score again!

When you are ready to submit your work, follow the instructions that are at the top of the score page.

### Academic Honesty

**DO NOT COPY** - Avoid plagiargism and adhere to the spirit of this [Academic Honesty Policy](https://www.freecodecamp.org/news/academic-honesty-policy/).
